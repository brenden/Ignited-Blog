-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 23, 2010 at 12:21 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projects`
--

-- --------------------------------------------------------

--
-- Table structure for table `jkblog_posts`
--

CREATE TABLE `jkblog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blogid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `body` text NOT NULL,
  `markdown` text NOT NULL,
  `date` varchar(256) NOT NULL,
  `tags` varchar(256) DEFAULT 'untagged',
  `commentlock` varchar(256) DEFAULT 'open',
  `deleted` varchar(256) DEFAULT 'false',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `tags` (`tags`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `jkblog_posts`
--

INSERT INTO `jkblog_posts` VALUES(1, 1, 1, 'Hello, World!', 'Let''s try this again.', 'Let''s try this again.', '05-05-2010 11:31:02', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(2, 1, 1, 'Hello, World! Part 2', 'Again, to test!', 'Again, to test!', '05-05-2010 11:34:28', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(3, 1, 1, 'Dad is Sleepy!', 'So sleepy!', 'So sleepy!', '05-05-2010 11:37:46', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(4, 1, 1, 'Hello, World! Injection style....', ''' " \\"<>', ''' " \\"<>', '05-05-2010 11:46:08', 'untagged', 'open', 'true');
INSERT INTO `jkblog_posts` VALUES(5, 1, 1, 'First Post!', '<p>Testing out the blog as a whole.</p>\n\n<p>Features to add:</p>\n\n<ul>\n<li>Markdown support</li>\n<li>HTML support</li>\n<li>Tags</li>\n<li>Moderation / editing tools</li>\n</ul>\n', 'Testing out the blog as a whole.\n\nFeatures to add:\n\n * Markdown support\n * HTML support\n * Tags\n * Moderation / editing tools\n', '05-06-2010 12:16:36', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(6, 1, 1, 'Testing redirection', 'Let''s see if this works any better.', 'Let''s see if this works any better.', '05-06-2010 12:19:02', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(7, 1, 1, 'Testing redirection', 'View test.', 'View test.', '05-06-2010 12:19:22', 'untagged', 'open', 'true');
INSERT INTO `jkblog_posts` VALUES(8, 1, 1, 'Testing redirection', 'View test.', 'View test.', '05-06-2010 12:19:22', 'untagged', 'open', 'true');
INSERT INTO `jkblog_posts` VALUES(9, 1, 1, 'Testing redirection', 'View test.', 'View test.', '05-06-2010 12:19:22', 'untagged', 'open', 'true');
INSERT INTO `jkblog_posts` VALUES(10, 1, 1, 'Tenth post', 'Creating the tenth and eleventh posts to test home page.', 'Creating the tenth and eleventh posts to test home page.', '05-06-2010 14:20:53', 'untagged', 'locked', 'true');
INSERT INTO `jkblog_posts` VALUES(11, 1, 1, '11th 1/2 Post', '<p>Test case <strong>again</strong>.\n<br />\nEnded up duplicating "11th Post" because of a bug. Good to catch those things... </p>\n', 'Test case **again**.\n<br />\nEnded up duplicating "11th Post" because of a bug. Good to catch those things... ', '05-06-2010 14:30:37', 'untagged test', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(12, 1, 1, '11th Post', 'Test case again.', 'Test case again.\n', '05-06-2010 14:30:37', 'untagged', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(13, 1, 1, 'Moving out!', '<p>I''m moving <strong>out</strong>! </p>\n\n<p>Today. Actually tomorrow. But still all good!</p>\n\n<p>This was actually a test of <a href="http://michelf.com/projects/php-markdown/">PHP Markdown</a>. Live update to come? Maybe.</p>\n\n<p>I''m am moving out though. To New York.</p>\n', 'I''m moving **out**! \n\nToday. Actually tomorrow. But still all good!\n\nThis was actually a test of [PHP Markdown](http://michelf.com/projects/php-markdown/). Live update to come? Maybe.\n\nI''m am moving out though. To New York.', '05-06-2010 18:30:25', 'untagged tag-test moving new-york markdown php', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(14, 1, 1, 'Finally think it''s ready to make a GIT repo', '<p>I''ve been dragging my heels with this <a href="http://git-scm.com/">GIT</a> repository. Partly because I don''t feel that when it''s just me developing there isn''t a reason to have a repository, and partly because <strong>I''ve been having too much fun coding!</strong>.</p>\n\n<p>Coding rocks and to see something take form like this with such (in my eyes) grace is something I <strong>hate</strong> to pull myself away from.</p>\n\n<p>In a couple of hours I''ll be on my way with a <a href="http://maps.google.com/maps?f=d&amp;source=s_d&amp;saddr=Michigan&amp;daddr=new+york&amp;geocode=FdwwpAIdxM_l-ikRBMrHPapMTTGzyWJ6WUjdlw%3BFR1AbQIdK8KW-yk7CD_TpU_CiTFi_nfhBo8LyA&amp;hl=en&amp;mra=ls&amp;sll=44.314844,-85.602364&amp;sspn=16.663441,36.430664&amp;ie=UTF8&amp;t=h&amp;z=6">14+ hour drive</a>. I''ll probably print out the <a href="http://ftp.newartisans.com/pub/git.from.bottom.up.pdf">Git from the bottom up</a> document and read that if I ever get a break from sleeping. </p>\n\n<p>Currently supported features:</p>\n\n<ul>\n<li>Posts</li>\n<li>Comments</li>\n<li>Editing posts</li>\n<li>Deleting posts</li>\n<li>Tagging posts</li>\n<li>Tag cloud displayed</li>\n<li>Login / out system</li>\n<li><a href="http://michelf.com/projects/php-markdown/">Markdown</a> posting</li>\n</ul>\n\n<p>Currently slated features:</p>\n\n<ul>\n<li>Next / Previous post buttons</li>\n<li>Statistics in side column</li>\n<li>Tag list (posts by tag)</li>\n<li>Basic search - to continually tune</li>\n<li>Tidy up the design</li>\n</ul>\n', 'I''ve been dragging my heels with this [GIT](http://git-scm.com/) repository. Partly because I don''t feel that when it''s just me developing there isn''t a reason to have a repository, and partly because **I''ve been having too much fun coding!**.\n\nCoding rocks and to see something take form like this with such (in my eyes) grace is something I **hate** to pull myself away from.\n\nIn a couple of hours I''ll be on my way with a [14+ hour drive](http://maps.google.com/maps?f=d&source=s_d&saddr=Michigan&daddr=new+york&geocode=FdwwpAIdxM_l-ikRBMrHPapMTTGzyWJ6WUjdlw%3BFR1AbQIdK8KW-yk7CD_TpU_CiTFi_nfhBo8LyA&hl=en&mra=ls&sll=44.314844,-85.602364&sspn=16.663441,36.430664&ie=UTF8&t=h&z=6). I''ll probably print out the [Git from the bottom up](http://ftp.newartisans.com/pub/git.from.bottom.up.pdf) document and read that if I ever get a break from sleeping. \n\nCurrently supported features:\n\n * Posts\n * Comments\n * Editing posts\n * Deleting posts\n * Tagging posts\n * Tag cloud displayed\n * Login / out system\n * [Markdown](http://michelf.com/projects/php-markdown/) posting\n\nCurrently slated features:\n\n * Next / Previous post buttons\n * Statistics in side column\n * Tag list (posts by tag)\n * Basic search - to continually tune\n * Tidy up the design', '05-07-2010 00:41:04', 'git update features this', 'open', 'false');
INSERT INTO `jkblog_posts` VALUES(15, 1, 1, 'Test tags', '<p>taggg</p>\n', 'taggg', '05-07-2010 00:49:42', 'tag test', 'open', 'true');
INSERT INTO `jkblog_posts` VALUES(16, 1, 1, 'Landed in New York', '<p>I have arrived in <a href="http://en.wikipedia.org/wiki/New_York">New York</a>. Actually I arrived a <a href="/projects/blog/index.php/blog/view/13/Moving-out!/">little bit earlier</a>, but I spent a lot of yesterday touring the city and wearing out my shoes.</p>\n\n<p>The subway and <a href="http://www.mta.info/lirr/">train</a> are not as complicated as they first appear. I''ve packed a train timetable and a subway map just in case though. </p>\n', 'I have arrived in [New York](http://en.wikipedia.org/wiki/New_York). Actually I arrived a [little bit earlier](/projects/blog/index.php/blog/view/13/Moving-out!/), but I spent a lot of yesterday touring the city and wearing out my shoes.\n\nThe subway and [train](http://www.mta.info/lirr/) are not as complicated as they first appear. I''ve packed a train timetable and a subway map just in case though. ', '05-09-2010 16:35:33', 'new-york general', 'open', 'false');
